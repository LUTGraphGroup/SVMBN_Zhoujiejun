Abstract

The significance of identifying metabolite-disease associations is self-evident. As research advances, computational method has surpassed traditional experiments in efficiency. Nevertheless, current computational methods often overlook the integration of multiple biological information. To address this limitation, we propose the algorithm based on support vector machine and biological network (SVMBN) for predicting metabolite-disease associations. Initially, six similarity calculation methods are employed to construct metabolite and disease similarity networks separately. Next, features are extracted using non-negative matrix factorization (NMF). Finally, support vector machine (SVM) predicts metabolite-disease links. Experimental results reveal SVMBN's AUC of 0.98 in 5-fold cross-validation, outperforming alternative methods. Case studies further validate SVMBN algorithm's ability to accurately forecast the relationships between metabolites and diseases.


=========================================


Running order: Prepared.py --> utils.py --> CV_Split_model.py