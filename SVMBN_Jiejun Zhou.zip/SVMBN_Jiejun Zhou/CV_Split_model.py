# 导入基本库
import numpy as np
import pandas as pd
from sklearn.svm import SVC
from utils import feature_1_1
from utils import label_1_1
from sklearn.metrics import roc_curve, roc_auc_score, auc, f1_score, precision_score, fbeta_score, recall_score
import matplotlib.pyplot as plt
plt.rc('font', family='Times New Roman')
plt.rcParams['font.size'] = 10
from sklearn.model_selection import StratifiedKFold, KFold
from scipy import interp
import math
from utils import MetSim, DisSim
from sklearn.model_selection import train_test_split
import os


def laplace(X1, X2):
    K = np.zeros((len(X1), len(X2)), dtype=float)
    for i in range(len(X1)):
        for j in range(len(X2)):
            K[i][j] = math.exp(-math.sqrt(np.dot(X1[i] - X2[j], (X1[i] - X2[j]).T))/8)
    return K


cv = StratifiedKFold(n_splits=5)
kf = KFold(n_splits=5, shuffle=True)
clf = SVC(kernel=laplace, C=100, probability=True)



tprs5 = []
aucs5 = []
acc5 = []
mean_fpr = np.linspace(0, 1, 100)

Feature = feature_1_1
Label = label_1_1
count = 0
i = 1
TPR = []
FPR = []
AUC = []
for train, test in kf.split(Feature, Label):
    clf.fit(Feature[train], Label[train])
    probas_ = clf.predict_proba(Feature[test])

    scores = clf.score(Feature[test], Label[test])
    acc5.append(scores)
    fpr, tpr, thresholds = roc_curve(Label[test], probas_[:, 1])


    tprs5.append(np.interp(mean_fpr, fpr, tpr))
    tprs5[-1][0] = 0.0
    roc_auc = auc(fpr, tpr)
    aucs5.append(roc_auc)
    count += 1
    print("第 %d 次循环" % (count) )
    plt.plot(fpr, tpr, lw=1, alpha=0.6, linestyle='--', label='ROC fold %d(AUC = %0.4f)' % (i, roc_auc))
    TPR.append(tpr)
    FPR.append(fpr)
    AUC.append(roc_auc)




Acc = np.mean(acc5)
print('Acc = ', Acc)
mean_tpr = np.mean(tprs5, axis=0)
mean_tpr[-1] = 1.0
mean_auc = np.mean(aucs5)
print('mean auc = ', mean_auc)


plt.plot(mean_fpr, mean_tpr, '-', color='r',
         label=r'Mean ROC (AUC = %0.4f )' % (mean_auc),
         lw=1.5, alpha=.8)




plt.plot([0, 1], [0, 1], linestyle='--', lw=1, color='gray', alpha=.6)



ax1 = plt.gca()
# ax1.patch.set_facecolor("gray")
ax1.patch.set_alpha(0.25)
ax1.yaxis.grid(color='k',
              linestyle='--',
              linewidth=1,
              alpha=0.3)



plt.figure(1)
plt.xlim([-0.05, 1.05])
plt.ylim([-0.05, 1.05])
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
# plt.title('Receiver operating characteristic example')
plt.legend(loc="lower right")
# plt.savefig('zhengti.pdf', dpi = 600)
plt.show()

plt.figure(2)
for i in range(0, len(TPR)):
    tpr0 = TPR[i]
    fpr0 = FPR[i]
    auc0 = AUC[i]
    plt.plot(fpr0, tpr0, lw=1, alpha=0.6, linestyle='--', label='ROC fold %d(AUC=%0.4f)' % (i+1, auc0))

plt.plot(mean_fpr, mean_tpr, '-', color='r',
         label=r'Mean ROC (AUC = %0.4f )' % (mean_auc),
         lw=1.5, alpha=.8)

ax1 = plt.gca()
# ax1.patch.set_facecolor("gray")
ax1.patch.set_alpha(0.25)
ax1.yaxis.grid(color='k',
              linestyle='--',
              linewidth=1,
              alpha=0.3)

plt.xlim([0.0, 0.45])
plt.ylim([0.85, 1.01])
plt.xlabel('False Positive Rate')
# plt.ylabel('True Positive Rate')
# plt.title('Receiver operating characteristic example')
# plt.legend(loc="lower right")
# plt.savefig('fangda.pdf', dpi = 600)
plt.show()

