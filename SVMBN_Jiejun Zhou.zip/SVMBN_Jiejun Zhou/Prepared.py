import numpy as np
import pandas as pd
import openpyxl
import xlwt
from scipy.spatial.distance import pdist
import math
from rdkit import Chem
from rdkit import DataStructs
from rdkit.Chem import AllChem

# 构建代谢物-疾病关联矩阵，存放于Matrix_HMDB.csv中
print("获取代谢物-疾病关联矩阵……")
# FinalData是经过预处理的233个疾病及其关联数据
FinalData = pd.read_csv('data/FinalData.csv')
FinalData_DiseaseName = FinalData['DiseaseName'].tolist()   # 获取所有233个疾病的名称
FinalData_Dis_MetaVector = FinalData['Dis_MetaVector'].tolist()     # 获取233个疾病对应的代谢物关联向量
Matrix_HMDB = np.zeros((len(eval(FinalData_Dis_MetaVector[0])), len(FinalData_DiseaseName)))     # 定义一个233*2260的0矩阵
Metabolites = pd.read_csv('data/Intersection_Metabolites.csv')
Unique_Metabolites = Metabolites['0'].tolist()      # 不重复的代谢物
for i in range(0, len(FinalData_Dis_MetaVector)):
    DMVector = eval(FinalData_Dis_MetaVector[i])
    for j in range(0, len(DMVector)):
        Matrix_HMDB[j, i] = DMVector[j]
pd.DataFrame(Matrix_HMDB).to_csv('data/Matrix_HMDB.csv')    # 导出代谢物-疾病关联矩阵
print("代谢物-疾病关联矩阵已导出！")


# 构建疾病相似性矩阵
print("正在构建疾病相似性矩阵……")
MeSH = pd.read_csv('data/MeSHID.csv', header=0)     # 获取MeSH文件
MeSH_DiseaseTemp = MeSH['disease'].tolist()     # MeSH_DiseaseTemp是MeSH文件中原始的疾病列
MeSH_IDTemp = MeSH['ID'].tolist()     # MeSH_IDTemp是MeSH文件中原始的代谢物ID列
Disease_Semantic_list = []    # 233个疾病的语义总表，表中元素还是列表，每一个列表代表一个疾病的语义集合
Disease_Semantic = []   # 233个疾病-语义字典构成的总表
for i in FinalData_DiseaseName:
    # print("疾病的名字是：", i)
    temp = []
    for j in range(0, len(MeSH_DiseaseTemp)):
        if i == MeSH_DiseaseTemp[j]:
            temp.append(MeSH_IDTemp[j])
            # print(MeSH_IDTemp[j])
    Disease_Semantic_list.append(temp)
# print("语义总表是：", Disease_Semantic_list)
for i in range(0, len(FinalData_DiseaseName)):
    Disease_Semantic.append({FinalData_DiseaseName[i]: Disease_Semantic_list[i]})      # 添加至字典中
# print("疾病-语义字典总表是：", Disease_Semantic)
# print("疾病-语义字典总表的长度是：", len(Disease_Semantic))

# 计算MeSH数据库中最长的语义长度，方便后面计算语义相似性
# compare = []
# for i in MeSH_IDTemp:
#     compare.append(len(i))
# print("MeSH数据库中最长的语义长度是：", max(compare))        # 是39

# 计算疾病语义相似性
print("正在计算疾病语义相似性……")
DVlist = []   # 所有的DV语义贡献值组成的列表
RDlist = []   # 去重疾病结点表总表
DLlist = []   # 结点深度表总表
for i in range(0, len(Disease_Semantic)):
    # print(str(list(Disease_Semantic[i])))
    for j in Disease_Semantic[i].values():
        templist = []
        j.sort(key=len, reverse=False)
        # print(j)
        for k in j:
            x = len(k)
            if x > 3:
                k_1 = k[:4]
                templist.append(k_1)
                x = x-4
                if x > 3:
                    k_1 = k[:8]
                    templist.append(k_1)
                    x = x - 4
                    if x > 3:
                        k_1 = k[:12]
                        templist.append(k_1)
                        x = x - 4
                        if x > 3:
                            k_1 = k[:16]
                            templist.append(k_1)
                            x = x - 4
                            if x > 3:
                                k_1 = k[:20]
                                templist.append(k_1)
                                x = x - 4
                                if x > 3:
                                    k_1 = k[:24]
                                    templist.append(k_1)
                                    x = x - 4
                                    if x > 3:
                                        k_1 = k[:28]
                                        templist.append(k_1)
                                        x = x - 4
                                        if x > 3:
                                            k_1 = k[:32]
                                            templist.append(k_1)
                                            x = x - 4
                                            if x > 3:
                                                k_1 = k[:36]
                                                templist.append(k_1)
                                                x = x - 4
                                                if x > 3:
                                                    k_1 = k[:40]
                                                    templist.append(k_1)
                                                    x = x - 4
                                                else:
                                                    templist.append(k)
                                            else:
                                                templist.append(k)
                                        else:
                                            templist.append(k)
                                    else:
                                        templist.append(k)
                                else:
                                    templist.append(k)
                            else:
                                templist.append(k)
                        else:
                            templist.append(k)
                    else:
                        templist.append(k)
                else:
                    templist.append(k)
            else:
                templist.append(k)
        # print('疾病结点表（未去重）：', templist)
        RemoveDuplicates = templist
        RemoveDuplicates = list(dict.fromkeys(RemoveDuplicates))
        # print('去重疾病结点表：', RemoveDuplicates)
        RDlist.append(RemoveDuplicates)
        b = 0
        deep_list = []      # 这是结点深度表，计算一个语义树每个结点的深度
        path_list = []      # 这是路径长度表
        addList = []
        for m in RemoveDuplicates:
            # print(m)
            a = '.'
            if m[-1:] == a:
                b = b + 1
                # print(b)
                deep_list.append(b)
            if m[-1:] != a:  # 如果是叶子节点，就归零重新计数
                b = -1
                b = b + 1
                # print(b)
                deep_list.append(b)
        # print('结点深度表：', deep_list)
        DLlist.append(deep_list)
        for n in range(0, len(deep_list)):
            if deep_list[n] == 0:  # 如果扫描到0，说明是叶子节点，就输出上一个的深度值，这就是最大的深度值，也就是路径长度
                path_list.append(deep_list[n - 1])
        # print('路径长度表：', path_list)
        c = 0
        for a in path_list:
            int(a)
            while a != 0:
                c = c + 0.5 ** a
                a = a - 1
            # print(c)
            addList.append(c)
            c = 0
        # print('语义贡献度表：', addList)
        DV = 1 + sum(addList)
        # print('疾病的语义贡献值：', DV)
        DVlist.append(DV)
# print(DVlist,len(DVlist))
# print(len(Mesh_Disease_unique))
# print('去重疾病结点表总表：', RDlist)
# print('结点深度表总表：', DLlist)
Disease_DV = []     # 这是疾病-语义值构成的字典
for i in range(0, len(FinalData_DiseaseName)):
    Disease_DV.append({FinalData_DiseaseName[i]: DVlist[i]})
# print('疾病-语义值构成的字典：', Disease_DV)

# 定义一个函数，计算两个疾病间的语义相似性
def ComputDSS(d_i, d_j):        # d_i, d_j是疾病在FinalData_DiseaseName数组中的序列号
    # print('RD1:',RDlist[d_i])
    # print('DL1:',DLlist[d_i])
    # print('RD2:',RDlist[d_j])
    # print('DL2:',DLlist[d_j])
    listdeepk = []
    listdeepl = []
    for i in  RDlist[d_i]:      # i扫描去重疾病节点表总表中的第d_i个疾病的去重表
        # print(i)
        for j in RDlist[d_j]:   # j扫描第d_j个疾病的去重表
            # print(j)
            if d_i == d_j:
                DSS = 1
                return DSS
            elif i == j and i[-1:] == '.':  # 如果i和j相等，且它们是非叶子结点
                index_di = RDlist[d_i].index(i)   # 将i在d_i个疾病的去重表中的索引返回
                index_dj = RDlist[d_j].index(j)
                # print('xxxx',index_di,index_dj)
                for k in range(index_di, len(DLlist[d_i])):  # k从第一个索引号开始遍历，到0就停，换上下一个索引号开始遍历下一个0
                    if DLlist[d_i][k] == 0:
                        deepk = k - index_di
                        listdeepk.append(deepk)
                        break
                for l in range(index_dj, len(DLlist[d_j])):
                    if DLlist[d_j][l] == 0:
                        deepl = l - index_dj
                        listdeepl.append(deepl)
                        break
    # print(listdeepk)
    # print(listdeepl)
    listdeepk_index = []
    listdeepl_index = []
    for m in listdeepk:
        listdeepk_index.append(0.5**m)
    for n in listdeepl:
        listdeepl_index.append(0.5**n)
    D_di = sum(listdeepk_index)
    D_dj = sum(listdeepl_index)
    DSS = (D_di + D_dj) / (DVlist[d_i] + DVlist[d_j])
    # print('疾病的DSS值是：',DSS)
    return DSS
DSM = np.zeros((len(FinalData_DiseaseName) , len(FinalData_DiseaseName)))   # 根据数据库需要修改 上次是Mesh_Disease_unique
for i in range(0, len(FinalData_DiseaseName)):     # 根据数据库需要修改 上次是Mesh_Disease_unique
    for j in range(0, len(FinalData_DiseaseName)):     # 根据数据库需要修改 上次是Mesh_Disease_unique
        a = round(ComputDSS(i, j), 5)
        DSM[i][j] = a
        DSM[j][i] = a
        # print("\r", end="")
        # print("进度: {}%: ".format(i), "▓" * (i // 2), end="")
        # sys.stdout.flush()
        # time.sleep(0.05)
# print(DSM)
pd.DataFrame(DSM).to_csv('data/Matrix_DSM.csv')
print("疾病语义相似性矩阵已导出！")

# 计算疾病的代谢物相似性
FinalData_Dis_SymVector = FinalData['Dis_SymVector'].tolist()
print("正在计算疾病代谢物相似性……")
# for i in range(0,len(A)):   # A[:,2]：读取第三列 ； A[2]：读取第三行 ； len(A)：统计行数 ； len(A[0])：统计列数
def Pearson(X, Y):
    XY = X * Y
    X2 = X ** 2
    Y2 = Y ** 2
    n = len(XY)
    numerator = n * XY.sum() - X.sum() * Y.sum()  # 分子
    denominator = math.sqrt(n * X2.sum() - X.sum() ** 2) * math.sqrt(n * Y2.sum() - Y.sum() ** 2)  # 分母
    if denominator == 0:
        return 'NaN'
    Pearson_index = numerator / denominator
    return math.fabs(round(Pearson_index, 5))
def MetabolitesSimilarity(d_i , d_j):
    IP_di = Matrix_HMDB[:, d_i]
    IP_dj = Matrix_HMDB[:, d_j]
    normlist = []
    for n in range(0, len(FinalData_DiseaseName)):
        normlist.append((np.linalg.norm(Matrix_HMDB[:, n], ord=2)) ** 2)
    sigemadi = sum(normlist)
    lambda_m = 1 / (1/len(FinalData_DiseaseName) * sigemadi)
    MS_Gaussian = np.exp(-lambda_m * ((np.linalg.norm((IP_di-IP_dj), ord=2)) ** 2))
    MS_Gaussian = round(MS_Gaussian, 5)
    MS_Pearson = Pearson(IP_di, IP_dj)
    if MS_Gaussian == 0:
        return MS_Pearson
    if MS_Gaussian != 0 and MS_Gaussian != 1:
        return MS_Gaussian
    if MS_Gaussian == 1 and d_i != d_j:
        return MS_Pearson
    if d_i == d_j:
        return MS_Gaussian
MSM = np.zeros((len(FinalData_DiseaseName) , len(FinalData_DiseaseName)))   # 根据数据库需要修改 上次是Mesh_Disease_unique
for i in range(0, len(FinalData_DiseaseName)):     # 根据数据库需要修改 上次是Mesh_Disease_unique
    for j in range(0, len(FinalData_DiseaseName)):     # 根据数据库需要修改 上次是Mesh_Disease_unique
        a = MetabolitesSimilarity(i, j)
        MSM[i][j] = a
        MSM[j][i] = a
        # print("\r", end="")
        # print("进度: {}%: ".format(i), "▓" * (i // 2), end="")
        # sys.stdout.flush()
        # time.sleep(0.05)
# print(MSM)
pd.DataFrame(MSM).to_csv('data/Matrix_MSM.csv')
print("疾病代谢物相似性矩阵已导出！")

# 计算疾病的症状相似性
print("正在计算疾病的症状相似性……")
def jaccard(V1, V2):
    count = 0
    for i in range(0, len(V1)):
        if V1[i] == V2[i] and V1[i] == 1:
            count = count + 1
    n = V1.count(1) + V2.count(1) -count
    jaccard_index = count/n
    return jaccard_index
def cosine(V1, V2):
    tmp = np.array((V1, V2))
    index = pdist(tmp,'cosine')
    cosine_index = float(index[0])
    return (1- cosine_index)
def SymptomSimilarity(d_i, d_j):
    sym_i = eval(FinalData_Dis_SymVector[d_i])
    sym_j = eval(FinalData_Dis_SymVector[d_j])
    jac = jaccard(sym_i, sym_j)
    cos = cosine(sym_i, sym_j)
    total = jac + cos
    jc_total = round(total, 5)
    if jac != 0 and cos != 0:
        return (jc_total / 2)
    else:
        return (jc_total)
SSM = np.zeros((len(FinalData_DiseaseName) , len(FinalData_DiseaseName)))   # 根据数据库需要修改 上次是Mesh_Disease_unique
for i in range(0, len(FinalData_Dis_SymVector)):
    for j in range(0, len(FinalData_Dis_SymVector)):
        a = SymptomSimilarity(i, j)
        SSM[i][j] = a
        SSM[j][i] = a
        # print("\r", end="")
        # print("进度: {}%: ".format(i), "▓" * (i // 2), end="")
        # sys.stdout.flush()
        # time.sleep(0.05)
# print(SSM)
pd.DataFrame(SSM).to_csv('data/Matrix_SSM.csv')
print("疾病症状相似性矩阵已导出！")

# 融合疾病相似性矩阵
print("正在融合疾病相似性矩阵……")
Matrix_DisSim = np.zeros((len(FinalData_DiseaseName) , len(FinalData_DiseaseName)))
for i in range(0, len(FinalData_Dis_SymVector)):
    for j in range(0, len(FinalData_Dis_SymVector)):
        DS = ComputDSS(i, j)
        MS = MetabolitesSimilarity(i, j)
        SS = SymptomSimilarity(i, j)
        AddList = [DS, MS, SS]
        if AddList.count(0) == 0:
            Matrix_DisSim[i][j] = round(np.sum(AddList)/3, 5)
            Matrix_DisSim[j][i] = round(np.sum(AddList)/3, 5)
        if AddList.count(0) == 1:
            Matrix_DisSim[i][j] = round(np.sum(AddList)/2, 5)
            Matrix_DisSim[j][i] = round(np.sum(AddList)/2, 5)
        if AddList.count(0) == 2:
            Matrix_DisSim[i][j] = round(float(np.sum(AddList)), 5)
            Matrix_DisSim[j][i] = round(float(np.sum(AddList)), 5)
        if AddList.count(0) == 3:
            Matrix_DisSim[i][j] = 0
            Matrix_DisSim[j][i] = 0
            # print("\r", end="")
            # print("进度: {}%: ".format(i), "▓" * (i // 2), end="")
            # sys.stdout.flush()
            # time.sleep(0.05)
print("疾病相似性矩阵已融合完成！")
pd.DataFrame(Matrix_DisSim).to_csv('data/Matrix_DisSim.csv')
print("疾病相似性矩阵已导出！")


# 构建代谢物相似性矩阵
print("正在构建代谢物相似性矩阵……")
HMDB = pd.read_excel('data/HMDB.xlsx')
HMDB_Metabolites = HMDB['代谢物ID'].tolist()
HMDB_SMILES = HMDB['SMILES'].tolist()
SMILEStemp = []
for i in range(0, len(Unique_Metabolites)):
    for j in range(0, len(HMDB_Metabolites)):
        if Unique_Metabolites[i] == HMDB_Metabolites[j]:
            SMILEStemp.append(HMDB_SMILES[j])
# print(SMILEStemp)
# print(len(SMILEStemp))

# 计算代谢物分子指纹相似性
print("正在计算代谢物分子指纹相似性……")
Unique_SMILE = []
for i in range(0,len(SMILEStemp)-1):
    if SMILEStemp[i] != SMILEStemp[i+1]:
        Unique_SMILE.append(SMILEStemp[i])
Unique_SMILE.append(SMILEStemp[len(SMILEStemp)-1])
# print(Unique_SMILE)
# print(len(Unique_SMILE))
MorganFingerPrint_biCode_ECFPs = []   # 二进制摩根指纹数组
MorganFingerPrint_biCode_FCFPs = []   # 二进制摩根指纹数组
for i in Unique_SMILE:
    mol = Chem.MolFromSmiles(i)
    fp = AllChem.GetMorganFingerprint(mol, 2)   # 默认的摩根指纹
    fp_biCode_ECFPs = AllChem.GetMorganFingerprintAsBitVect(mol, 2, nBits=1024)  # ECFPs摩根指纹的二进制形式
    fp_biCode_FCFPs = AllChem.GetMorganFingerprintAsBitVect(mol, 2, nBits=1024, useFeatures=True)
    MorganFingerPrint_biCode_ECFPs.append(fp_biCode_ECFPs)
    MorganFingerPrint_biCode_FCFPs.append(fp_biCode_FCFPs)
def FingerprintSimilarity(d_i, d_j):
    ME_i = MorganFingerPrint_biCode_ECFPs[d_i]
    ME_j = MorganFingerPrint_biCode_ECFPs[d_j]
    SIM_ECFPS = DataStructs.TanimotoSimilarity(ME_i, ME_j)
    MF_i = MorganFingerPrint_biCode_FCFPs[d_i]
    MF_j = MorganFingerPrint_biCode_FCFPs[d_j]
    SIM_FCFPS = DataStructs.TanimotoSimilarity(MF_i, MF_j)
    if SIM_FCFPS != 0 and SIM_ECFPS != 0:
        return (SIM_ECFPS+SIM_FCFPS)/2
    else:
        return SIM_ECFPS+SIM_FCFPS
Matrix_FSM = np.zeros((len(Unique_Metabolites), len(Unique_Metabolites)))
for i in range(0,len(Unique_Metabolites)):
    for j in range(0,len(Unique_Metabolites)):
        Matrix_FSM[i][j] = FingerprintSimilarity(i, j)
        Matrix_FSM[j][i] = FingerprintSimilarity(i, j)
        # print("\r", end="")
        # print("进度: {}%: ".format(i), "▓" * (i // 2), end="")
        # sys.stdout.flush()
        # time.sleep(0.05)
pd.DataFrame(Matrix_FSM).to_csv('data/Matrix_FSM.csv')
print("代谢物分子指纹相似性矩阵已导出！")

# 计算代谢物功能相似性
print("正在计算代谢物功能相似性……")
def MetaSimilarity(m_i, m_j):       # 输入代谢物序号
    MD_i = Matrix_HMDB[m_i]
    MD_j = Matrix_HMDB[m_j]
    Mi_diseaseIndex = []
    Mj_diseaseIndex = []
    for i in range(0, len(MD_i)):
        if MD_i[i] == 1:
            Mi_diseaseIndex.append(i)
    # print(Mi_diseaseIndex)
    for j in range(0, len(MD_j)):
        if MD_j[j] == 1:
            Mj_diseaseIndex.append(j)
    # print(Mj_diseaseIndex)
    tmp01 = []
    for i in Mi_diseaseIndex:
        metasimVal = 0
        tmp02 = []
        for j in Mj_diseaseIndex:
            metasimVal = Matrix_DisSim[i][j]
            tmp02.append(metasimVal)
        # print('tmp02:', tmp02)
        tmp01.append(max(tmp02))
    # print('tmp01:', tmp01)
    tmp03 = []
    for i in Mj_diseaseIndex:
        metasimVal = 0
        tmp04 = []
        for j in Mi_diseaseIndex:
            metasimVal = Matrix_DisSim[i][j]
            tmp04.append(metasimVal)
        # print('tmp04:', tmp04)
        tmp03.append(max(tmp04))
    # print('tmp03:', tmp03)
    return float(sum(tmp01)+sum(tmp03))/(len(Mi_diseaseIndex)+len(Mj_diseaseIndex))
Matrix_GSM = np.zeros((len(Unique_Metabolites), len(Unique_Metabolites)))       # 代谢物功能相似性矩阵
for i in range(0,len(Unique_Metabolites)):
    for j in range(0,len(Unique_Metabolites)):
        Matrix_GSM[i][j] = MetaSimilarity(i, j)
        Matrix_GSM[j][i] = MetaSimilarity(i, j)
        # print(MetaSimilarity(i, j))
        # print("\r", end="")
        # print("进度: {}%: ".format(i), "▓" * (i // 2), end="")
        # sys.stdout.flush()
        # time.sleep(0.05)
pd.DataFrame(Matrix_GSM).to_csv('Matrix_GSM.csv')
print("代谢物功能相似性矩阵已导出！")

# 计算代谢物疾病相似性
print("正在计算代谢物疾病相似性……")
def DiseaseSimilarity(m_i , m_j):
    IP_mi = Matrix_HMDB[m_i]
    IP_mj = Matrix_HMDB[m_j]
    normlist = []
    for n in range(0, len(Unique_Metabolites)):
        normlist.append((np.linalg.norm(Matrix_HMDB[n], ord=2)) ** 2)
    sigemadi = sum(normlist)
    lambda_m = 1 / (1/len(Unique_Metabolites) * sigemadi)
    DS_Gaussian = np.exp(-lambda_m * ((np.linalg.norm((IP_mi-IP_mj), ord=2)) ** 2))
    DS_Gaussian = round(DS_Gaussian, 5)
    DS_Pearson = Pearson(IP_mi, IP_mj)
    if DS_Gaussian == 0:
        return DS_Pearson
    if DS_Gaussian != 0 and DS_Gaussian != 1:
        return DS_Gaussian
    if DS_Gaussian == 1 and m_i != m_j:
        return DS_Pearson
    if m_i == m_j:
        return DS_Gaussian
Matrix_JSM = np.zeros((len(Unique_Metabolites), len(Unique_Metabolites)))       # 代谢物功能相似性矩阵
for i in range(0,len(Unique_Metabolites)):
    for j in range(0,len(Unique_Metabolites)):
        Matrix_JSM[i][j] = DiseaseSimilarity(i, j)
        Matrix_JSM[j][i] = DiseaseSimilarity(i, j)
        print(DiseaseSimilarity(i, j))
        # print("\r", end="")
        # print("进度: {}%: ".format(i), "▓" * (i // 2), end="")
        # sys.stdout.flush()
        # time.sleep(0.05)
pd.DataFrame(Matrix_JSM).to_csv('Matrix_JSM.csv')
print("代谢物疾病相似性矩阵已导出！")

# 融合代谢物相似性矩阵
print("正在融合代谢物相似性矩阵……")
Matrix_MetSim = np.zeros((len(Unique_Metabolites) , len(Unique_Metabolites)))
for i in range(0, len(Unique_Metabolites)):
    for j in range(0, len(Unique_Metabolites)):
        FS = Matrix_FSM[i][j]
        ES = Matrix_GSM[i][j]
        IS = Matrix_JSM[i][j]
        AddList = [FS, ES, IS]
        if AddList.count(0) == 0:
            Matrix_MetSim[i][j] = round(np.sum(AddList)/3, 5)
            Matrix_MetSim[j][i] = round(np.sum(AddList)/3, 5)
        if AddList.count(0) == 1:
            Matrix_MetSim[i][j] = round(np.sum(AddList)/2, 5)
            Matrix_MetSim[j][i] = round(np.sum(AddList)/2, 5)
        if AddList.count(0) == 2:
            Matrix_MetSim[i][j] = round(float(np.sum(AddList)), 5)
            Matrix_MetSim[j][i] = round(float(np.sum(AddList)), 5)
        if AddList.count(0) == 3:
            Matrix_MetSim[i][j] = 0
            Matrix_MetSim[j][i] = 0
            # print("进度: {}%: ".format(i), "▓" * (i // 2), end="")
            # sys.stdout.flush()
            # time.sleep(0.05)
print("代谢物相似性矩阵已融合完成！")
pd.DataFrame(Matrix_MetSim).to_csv('data/Matrix_MetSim.csv')
print("代谢物相似性矩阵已导出！")
