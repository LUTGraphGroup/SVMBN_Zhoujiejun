import random
import numpy as np
import pandas as pd
import openpyxl
import xlwt
import math
import sklearn.discriminant_analysis as sk_discriminant_analysis
from sklearn.decomposition import NMF


from sklearn.svm import SVC
from sklearn.metrics import roc_curve, roc_auc_score, auc, f1_score, precision_score, fbeta_score
import matplotlib.pyplot as plt
from sklearn.model_selection import StratifiedKFold, KFold
from scipy import interp


df1 = pd.read_csv('data/Matrix_DisSim.csv')
df2 = pd.read_csv('data/Matrix_MetSim.csv')
DisSim = df1.values
MetSim = df2.values
DisSim = np.delete(DisSim, 0, axis=1)
MetSim = np.delete(MetSim, 0, axis=1)

df3 = pd.read_csv('data/Matrix_HMDB.csv')
Association_matrix = df3.values
Association_matrix = np.delete(Association_matrix, 0, axis=1)

# r = [50, 100, 150, 200, 250]
# it = [50, 100, 150, 200, 250]
nmf = NMF(n_components=150, init='random', random_state=0, max_iter=250)# 150 250


# 一共有526580个关联边
Association_index = []  # 4470个正样本
for i in range(0, np.size(Association_matrix, 0)):
    for j in range(0, np.size(Association_matrix, 1)):
        index = []
        if Association_matrix[i][j] == 1:
            index.append(i)
            index.append(j)
            Association_index.append(index)

Nonassociation_index = []   # 522110个负样本
for i in range(0, np.size(Association_matrix, 0)):
    for j in range(0, np.size(Association_matrix, 1)):
        index = []
        if Association_matrix[i][j] == 0:
            index.append(i)
            index.append(j)
            Nonassociation_index.append(index)



feature_positive = np.zeros((4470, 2493), dtype=float)
for i in range(0, len(Association_index)):
    templist = Association_index[i]
    Met_index = templist[0]
    Dis_index = templist[1]
    Met_vec = np.array(MetSim[Met_index, :].tolist())
    Dis_vec = np.array(DisSim[Dis_index, :].tolist())
    feature_vec = np.hstack([Met_vec, Dis_vec])
    feature_positive[i, :] = feature_vec
label_positive = np.ones((4470, ))
count = 0
sample_nona = random.sample(Nonassociation_index, 4470)
feature_negative = np.zeros((4470, 2493), dtype=float)
for i in range(0, len(sample_nona)):
    templist = sample_nona[i]
    Met_index = templist[0]
    Dis_index = templist[1]
    Met_vec = np.array(MetSim[Met_index, :].tolist())
    Dis_vec = np.array(DisSim[Dis_index, :].tolist())
    feature_vec = np.hstack([Met_vec, Dis_vec])
    feature_negative[i, :] = feature_vec
label_negative = np.zeros((4470, ))
feature_1_1 = np.vstack([feature_positive, feature_negative])
label_1_1 = np.hstack([label_positive, label_negative])

nmf.fit(feature_1_1)
W = nmf.fit_transform(feature_1_1)
H = nmf.components_
# feature_1_1 = nmf.transform(feature_1_1)
feature_1_1 = W
print(feature_1_1.shape)


feature_positive = np.zeros((4470, 2493), dtype=float)
for i in range(0, len(Association_index)):
    templist = Association_index[i]
    Met_index = templist[0]
    Dis_index = templist[1]
    Met_vec = np.array(MetSim[Met_index, :].tolist())
    Dis_vec = np.array(DisSim[Dis_index, :].tolist())
    feature_vec = np.hstack([Met_vec, Dis_vec])
    feature_positive[i, :] = feature_vec
label_positive = np.ones((4470, ))
count = 0
sample_nona = random.sample(Nonassociation_index, 8940)
feature_negative = np.zeros((8940, 2493), dtype=float)
for i in range(0, len(sample_nona)):
    templist = sample_nona[i]
    Met_index = templist[0]
    Dis_index = templist[1]
    Met_vec = np.array(MetSim[Met_index, :].tolist())
    Dis_vec = np.array(DisSim[Dis_index, :].tolist())
    feature_vec = np.hstack([Met_vec, Dis_vec])
    feature_negative[i, :] = feature_vec
label_negative = np.zeros((8940, ))
feature_1_2 = np.vstack([feature_positive, feature_negative])
label_1_2 = np.hstack([label_positive, label_negative])
nmf.fit(feature_1_2)
W = nmf.fit_transform(feature_1_2)
H = nmf.components_
# feature_1_1 = nmf.transform(feature_1_1)
feature_1_2 = W
print(feature_1_2.shape)




feature_positive = np.zeros((4470, 2493), dtype=float)
for i in range(0, len(Association_index)):
    templist = Association_index[i]
    Met_index = templist[0]
    Dis_index = templist[1]
    Met_vec = np.array(MetSim[Met_index, :].tolist())
    Dis_vec = np.array(DisSim[Dis_index, :].tolist())
    feature_vec = np.hstack([Met_vec, Dis_vec])
    feature_positive[i, :] = feature_vec
label_positive = np.ones((4470, ))
count = 0
sample_nona = random.sample(Nonassociation_index, 13410)
feature_negative = np.zeros((13410, 2493), dtype=float)
for i in range(0, len(sample_nona)):
    templist = sample_nona[i]
    Met_index = templist[0]
    Dis_index = templist[1]
    Met_vec = np.array(MetSim[Met_index, :].tolist())
    Dis_vec = np.array(DisSim[Dis_index, :].tolist())
    feature_vec = np.hstack([Met_vec, Dis_vec])
    feature_negative[i, :] = feature_vec
label_negative = np.zeros((13410, ))
feature_1_3 = np.vstack([feature_positive, feature_negative])
label_1_3 = np.hstack([label_positive, label_negative])
nmf.fit(feature_1_3)
W = nmf.fit_transform(feature_1_3)
H = nmf.components_
# feature_1_1 = nmf.transform(feature_1_1)
feature_1_3 = W
print(feature_1_3.shape)

